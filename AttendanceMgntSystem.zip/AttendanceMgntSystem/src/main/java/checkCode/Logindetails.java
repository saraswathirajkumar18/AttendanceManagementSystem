package checkCode;

//import java.io.IOException;
import java.io.*; 
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import jxl.Workbook;
import jxl.Sheet;
//import jxl.Workbook;
import jxl.read.biff.BiffException;

public class Logindetails {
	WebDriver driver;
	String[][] userdata;
	@BeforeSuite
	@Parameters({"browsername"})
	public void browserSetup(String bname)
	{
		switch(bname)
		{
		case "chrome":
		    driver=new ChromeDriver();
		    break;
		case "firefox":
			  driver = new FirefoxDriver();
		      break;
		case "edge":
			driver = new EdgeDriver();
		      break;
	    default:System.out.println("Pls choose any one from these browsers:chrome,Firefox,Microsoft Edge");
		
		}
		driver.manage().window().maximize();
		driver.navigate().to("https://facegenie-ams-school.web.app/");
		}
	
	
	 @DataProvider(name="excelData") 
	 public String[][] loginDetails() throws BiffException, IOException 
	 { 
	 userdata=readExcelData(); 
	 return userdata; 
	 }
	
	
	public String[][] readExcelData() throws BiffException, IOException
		
{
	FileInputStream excelfile=new FileInputStream("C:\\Users\\krajk\\eclipse-workspace\\Mycode\\src\\main\\resources\\newdata.xls");
	Workbook book=Workbook.getWorkbook(excelfile);
	Sheet excelsheet=book.getSheet(0);
	int noofrow=excelsheet.getRows();
	int noofcol=excelsheet.getColumns();
	String exceldata[][]=new String[noofrow-1][noofcol];
	for(int i=1;i<noofrow;i++)
	{
		for(int j=0;j<noofcol;j++)
		{
		exceldata[i-1][j]=excelsheet.getCell(j, i).getContents(); 	
		}
	}
	return exceldata;
}
	@Test(dataProvider="excelData")
	public void checkLogin(String emailid,String pass) 
	{
		
		WebElement emailAddress=driver.findElement(By.id("email"));
		emailAddress.click();
		emailAddress.clear();
		emailAddress.sendKeys(emailid);
		//emailAddress.sendKeys("testbams@gmail.com");
		//emailAddress.sendKeys("uname");
		WebElement password=driver.findElement(By.id("password"));
		password.click();
		password.clear();
		//password.sendKeys("facegenie");
		password.sendKeys(pass);
		//System.out.println("finished");
		WebElement loginbutton=driver.findElement(By.xpath("//button[contains(text(),'Log In')]"));
		loginbutton.click();
		System.out.println("finished");
		//Thread.sleep(3000);
		//WebElement logoff=driver.findElement(By.xpath("//span[text()='Setting']/following::div[@role='button']"));
		//logoff.click();
	//System.out.println("finished");

	}
	
	@AfterSuite
	public void closeBrowser()
	{
	driver.close();
	}

}
