package checkCode;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Simple {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
System.out.print("kjkjjk");
		// TODO Auto-generated method stub
		//System.setProperty("webdriver.chrome.driver","C:\\Users\\krajk\\OneDrive\\Desktop\\chromedriver-win64\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		//driver.manage().window().maximize();
		driver.manage().window().maximize();
		driver.navigate().to("https://facegenie-ams-school.web.app/");
		System.out.println("finished");
		WebElement emailAddress=driver.findElement(By.id("email"));
		emailAddress.click();
		//emailAddress.sendKeys("testbams@gmail.com");
		emailAddress.sendKeys("uname");
		WebElement password=driver.findElement(By.id("password"));
		password.click();
		//password.sendKeys("facegenie");
		password.sendKeys("upass");
		System.out.println("finished");
		WebElement loginbutton=driver.findElement(By.xpath("//button[contains(text(),'Log In')]"));
		loginbutton.click();
		System.out.println("finished");
		Thread.sleep(3000);
		//WebElement logoff=driver.findElement(By.xpath("//span[text()='Setting']/following::div[@role='button']"));
		//logoff.click();
	//System.out.println("finished");


	}

}
